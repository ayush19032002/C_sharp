﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace connection
{
    public partial class home : Form
    {
        int curr_reco=0;
        int tot_reco;
        DataTable dt = new DataTable();
        int u = 0;
        String Username = "";

        public home()
        {
            InitializeComponent();
        }

        private void home_Load(object sender, EventArgs e)
        {
            display();
        }
      

        private void display()
        {
            string s = "select * from login";
            SqlDataAdapter da = new SqlDataAdapter(s, Class1.c);
            dt.Reset();
            da.Fill(dt);
            navi();
            tot_reco = dt.Rows.Count;
        }

        private void navi()
        {
            tot_reco=dt.Rows.Count;
            if (tot_reco >= 1)
            {
                textBox1.Text = dt.Rows[curr_reco]["username"].ToString();

                textBox2.Text = dt.Rows[curr_reco]["password"].ToString();
            }
          
        }

        
        private void button3_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            a.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            curr_reco = 0;
            navi();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            curr_reco = tot_reco - 1;
            navi();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            registration r = new registration();
            r.Show();
            this.Hide();
        }

        

        private void home_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (curr_reco < tot_reco - 1)
            {
                curr_reco++;
                navi();
            }
            else
            {
                MessageBox.Show("No Records..");
            }

        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            if (curr_reco > 0)
            {
                curr_reco--;
                navi();
            }
            else
            {
                MessageBox.Show("Already Exits");
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (u == 0)
            {
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                u = 1;
                Username = textBox1.Text;
            }
            else if(u >= 1)
            {
               
                String upd = "update login set username = '" + textBox1.Text + "' , password = '" + textBox2.Text + "' where username = '"+Username+"'";
              //  MessageBox.Show(upd);
               SqlDataAdapter da = new SqlDataAdapter(upd, Class1.c);
                DataTable d = new DataTable();
                d.Reset();
                int a= da.Fill(d);

                if (a >= 0)
                {
                    MessageBox.Show("Updated..");
                    display();
                }
                else
                {
                    MessageBox.Show("Not Updated..");

                }
               

            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (u == 0)
            {
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                u = 1;
                Username = textBox1.Text;
            }
            else if (u >= 1)
            {
                Username = textBox1.Text;
                String upd = "delete from login where username = '" + Username + "'";
               //MessageBox.Show(upd);
                SqlDataAdapter da = new SqlDataAdapter(upd, Class1.c);
                DataTable d = new DataTable();
                d.Reset();
                int a = da.Fill(d);

                if (a >= 0)
                {
                    MessageBox.Show("Deleted..");
                    display();
                    clear();

                }
                else
                {
                    MessageBox.Show("Not Deleted..");

                }
                display();

            }

        }

       
       

    }
}
