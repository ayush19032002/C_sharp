﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace student_result
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && comboBox1.Text != "" && textBox6.Text != "" && textBox7.Text != "")
            {
                string i = "insert into student values('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + comboBox1.Text + "','" + textBox6.Text + "','" + textBox7.Text + "')";
                SqlDataAdapter d = new SqlDataAdapter(i, Class1.c);
                DataTable dt = new DataTable();
                int a = d.Fill(dt);

                if (a == 0)
                {
                    MessageBox.Show("Inserted..", "database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clear();

                    Form2 f = new Form2();
                    f.Show();
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("Not Inserted..", "database", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    clear();
                }
            }
            else
            {
                MessageBox.Show("Please Enter Values:");
            }
           
        }

        private void clear()
        {
           
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox2.Focus();
        }

      
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
            this.Hide();
        

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
