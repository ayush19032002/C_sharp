﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace gridview_select
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            if (txtnm1.Text != "" && txtrlno.Text != "" && comboBox1.Text != "")
            {
                string sql = "insert into stud_info values('" + txtnm1.Text + "','" + txtrlno.Text + "','" + comboBox1.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, conn.cn);
                DataTable dt = new DataTable();
                int a = da.Fill(dt);
                clear();
            }
            else
            {
                MessageBox.Show("fill up the form properly");
            }
          
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            disp();
        }
        private void clear()
        {
            txtnm1.Text = "";
            txtrlno.Text = "";
            comboBox1.Text = "";
            txtnm1.Focus();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            clear();
        }
        private void disp()
        {
            string sql = "select * from stud_info";
            SqlDataAdapter da = new SqlDataAdapter(sql, conn.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
        }
    }
}
