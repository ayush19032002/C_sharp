﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Result
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Display();
        }
        private void Display()
        {
            string sel = "select * from reg_data";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cn);
            int a = sda.Fill(Class1.dt);
            dataGridView1.DataSource = Class1.dt;
        }
    }
}
